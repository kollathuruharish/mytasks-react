import logo from './logo.svg';
import './App.css';
import Index from './Task';
import Userinput from './Task/Userinput';

function App() {
  return (
    <div className="App">
    <Index/>
    <hr/>
    <Userinput/>
    </div>
  );
}

export default App;
