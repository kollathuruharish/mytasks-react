import React, { useState } from 'react'

const Userinput = () => {
    const [userData, setUserData] = useState({ str1: "", str2: "" });
    const [value, setValue] = useState()
    const handleInput = (e) => {
        let myUser = { ...userData }
        myUser[e.target.name] = e.target.value
        setUserData(myUser)
    }
    const addData = () => {
        setValue(userData)
    }
    return (
        <div>
            <div>
                <form>
                    Str 1 :<input type='text' name='str1' value={userData.str1} onChange={(e) => { handleInput(e) }} /> <br />
                    Str 2 :<input type='text' name='str2' value={userData.str2} onChange={(e) => { handleInput(e) }} /> <br />
                    <button type='button' onClick={addData}>Add</button>
                </form>
            </div>
            {value ?
                <div>
                    <p>Str 1: {value ? value.str1 : null}</p>
                    <p>Str 2 : {value ? value.str2 : null}</p>
                </div>
                : null}
        </div>
    )
}
export default Userinput;